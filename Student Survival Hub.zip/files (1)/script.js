(() => {
  'use strict';

  const CIRC = 2 * Math.PI * 86; // matches CSS r=86

  function setRing(el, percent) {
    const offset = CIRC - (CIRC * Math.min(Math.max(percent, 0), 100)) / 100;
    el.style.strokeDasharray = String(CIRC);
    el.style.strokeDashoffset = String(offset);
  }

  function uid() {
    return Math.random().toString(36).slice(2, 10);
  }

  function safeLoad(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }
  function safeSave(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
     
    }
  }

  // Theme toggle
  const themeToggle = document.getElementById('theme-toggle');
  const root = document.documentElement;

  function applyTheme(theme) {
    if (theme === 'dark') {
      root.setAttribute('data-theme', 'dark');
      themeToggle.setAttribute('aria-pressed', 'true');
      themeToggle.setAttribute('aria-label', 'Switch to light mode');
    } else {
      root.removeAttribute('data-theme');
      themeToggle.setAttribute('aria-pressed', 'false');
      themeToggle.setAttribute('aria-label', 'Switch to dark mode');
    }
  }
  const storedTheme = localStorage.getItem('ssh-theme');
  if (storedTheme) {
    applyTheme(storedTheme);
  } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
    applyTheme('dark');
  }
  themeToggle.addEventListener('click', () => {
    const isDark = root.getAttribute('data-theme') === 'dark';
    const next = isDark ? 'light' : 'dark';
    applyTheme(next);
    localStorage.setItem('ssh-theme', next);
  });

  // Mobile nav + scrollspy
  const navToggle = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('nav-menu');

  function closeMenu() {
    navMenu.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
    navToggle.setAttribute('aria-label', 'Open menu');
  }
  function openMenu() {
    navMenu.classList.add('is-open');
    navToggle.setAttribute('aria-expanded', 'true');
    navToggle.setAttribute('aria-label', 'Close menu');
  }
  navToggle.addEventListener('click', () => {
    navMenu.classList.contains('is-open') ? closeMenu() : openMenu();
  });
  document.querySelectorAll('[data-tab]').forEach(link => {
    link.addEventListener('click', closeMenu);
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });

  const navLinks = document.querySelectorAll('.nav-link');
  const spySections = Array.from(navLinks).map(link => document.querySelector(link.getAttribute('href')));
  const spyObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      const link = document.querySelector(`.nav-link[href="#${entry.target.id}"]`);
      if (!link) return;
      if (entry.isIntersecting) {
        navLinks.forEach(l => l.classList.remove('is-active'));
        link.classList.add('is-active');
      }
    });
  }, { rootMargin: '-40% 0px -55% 0px' });
  spySections.forEach(sec => { if (sec) spyObserver.observe(sec); });

  // Shared chime (used by Pomodoro)
  let audioCtx = null;
  let masterGain = null;

  function ensureAudio() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      masterGain = audioCtx.createGain();
      masterGain.gain.value = ((parseInt(volumeSlider?.value ?? '40', 10)) / 100) * 0.5;
      masterGain.connect(audioCtx.destination);
    }
    if (audioCtx.state === 'suspended') audioCtx.resume();
    return audioCtx;
  }

  function playChime() {
    const ctx = ensureAudio();
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0, now + i * 0.15);
      gain.gain.linearRampToValueAtTime(0.2, now + i * 0.15 + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.15 + 1.2);
      osc.connect(gain);
      gain.connect(masterGain);
      osc.start(now + i * 0.15);
      osc.stop(now + i * 0.15 + 1.3);
    });
  }

  // CGPA Calculator
  const GRADE_POINTS = {
    'A+': 4.0, 'A': 4.0, 'A-': 3.7,
    'B+': 3.3, 'B': 3.0, 'B-': 2.7,
    'C+': 2.3, 'C': 2.0, 'C-': 1.7,
    'D+': 1.3, 'D': 1.0, 'D-': 0.7,
    'F': 0.0
  };
  const cgpaRowsEl = document.getElementById('cgpa-rows');
  const addCourseBtn = document.getElementById('add-course');
  const prevCgpaInput = document.getElementById('prev-cgpa');
  const prevCreditsInput = document.getElementById('prev-credits');
  const semesterGpaEl = document.getElementById('semester-gpa');
  const cumulativeGpaEl = document.getElementById('cumulative-gpa');

  let cgpaCourses = safeLoad('ssh-cgpa-courses', null) || [
    { id: uid(), name: '', credits: 3, grade: 'A' },
    { id: uid(), name: '', credits: 3, grade: 'B+' }
  ];
  const savedPrev = safeLoad('ssh-cgpa-prev', {});
  if (savedPrev.cgpa != null) prevCgpaInput.value = savedPrev.cgpa;
  if (savedPrev.credits != null) prevCreditsInput.value = savedPrev.credits;

  function gradeOptions(selected) {
    return Object.keys(GRADE_POINTS).map(g =>
      `<option value="${g}" ${g === selected ? 'selected' : ''}>${g}</option>`
    ).join('');
  }

  function renderCgpaRows() {
    cgpaRowsEl.innerHTML = cgpaCourses.map(row => `
      <tr data-id="${row.id}">
        <td><input type="text" class="course-name" placeholder="Course name" value="${row.name.replace(/"/g, '&quot;')}"></td>
        <td><input type="number" class="course-credits" min="0" max="12" step="0.5" value="${row.credits}"></td>
        <td><select class="course-grade">${gradeOptions(row.grade)}</select></td>
        <td><button type="button" class="remove-row-btn" aria-label="Remove course">✕</button></td>
      </tr>
    `).join('');
  }

  function computeCgpa() {
    let totalCredits = 0;
    let totalPoints = 0;
    cgpaCourses.forEach(row => {
      const credits = parseFloat(row.credits) || 0;
      const points = GRADE_POINTS[row.grade] ?? 0;
      totalCredits += credits;
      totalPoints += credits * points;
    });
    const semesterGpa = totalCredits > 0 ? totalPoints / totalCredits : 0;

    const prevCgpa = parseFloat(prevCgpaInput.value) || 0;
    const prevCredits = parseFloat(prevCreditsInput.value) || 0;
    const combinedCredits = prevCredits + totalCredits;
    const cumulativeGpa = combinedCredits > 0
      ? (prevCgpa * prevCredits + totalPoints) / combinedCredits
      : semesterGpa;

    semesterGpaEl.textContent = semesterGpa.toFixed(2);
    cumulativeGpaEl.textContent = cumulativeGpa.toFixed(2);
  }

  function persistCgpa() {
    safeSave('ssh-cgpa-courses', cgpaCourses);
    safeSave('ssh-cgpa-prev', { cgpa: prevCgpaInput.value, credits: prevCreditsInput.value });
  }

  cgpaRowsEl.addEventListener('input', (e) => {
    const tr = e.target.closest('tr');
    if (!tr) return;
    const row = cgpaCourses.find(r => r.id === tr.dataset.id);
    if (!row) return;
    if (e.target.classList.contains('course-name')) row.name = e.target.value;
    if (e.target.classList.contains('course-credits')) row.credits = e.target.value;
    if (e.target.classList.contains('course-grade')) row.grade = e.target.value;
    computeCgpa();
    persistCgpa();
  });

  cgpaRowsEl.addEventListener('click', (e) => {
    if (!e.target.classList.contains('remove-row-btn')) return;
    const tr = e.target.closest('tr');
    cgpaCourses = cgpaCourses.filter(r => r.id !== tr.dataset.id);
    renderCgpaRows();
    computeCgpa();
    persistCgpa();
  });

  addCourseBtn.addEventListener('click', () => {
    cgpaCourses.push({ id: uid(), name: '', credits: 3, grade: 'A' });
    renderCgpaRows();
    computeCgpa();
    persistCgpa();
  });

  [prevCgpaInput, prevCreditsInput].forEach(input => {
    input.addEventListener('input', () => { computeCgpa(); persistCgpa(); });
  });

  renderCgpaRows();
  computeCgpa();

  // Semester Planner
  const plannerBody = document.getElementById('planner-body');
  const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const HOURS = Array.from({ length: 14 }, (_, i) => i + 8); 

  function formatHour(h) {
    const period = h >= 12 ? 'PM' : 'AM';
    const hour12 = h % 12 === 0 ? 12 : h % 12;
    return `${hour12}:00 ${period}`;
  }

  const plannerData = safeLoad('ssh-planner', {});

  plannerBody.innerHTML = HOURS.map(hour => `
    <tr>
      <td>${formatHour(hour)}</td>
      ${DAYS.map(day => {
        const key = `${day}-${hour}`;
        const val = (plannerData[key] || '').replace(/"/g, '&quot;');
        return `<td><input type="text" class="planner-cell" data-key="${key}" value="${val}" aria-label="${day} at ${formatHour(hour)}"></td>`;
      }).join('')}
    </tr>
  `).join('');

  let plannerSaveTimer = null;
  plannerBody.addEventListener('input', (e) => {
    if (!e.target.classList.contains('planner-cell')) return;
    plannerData[e.target.dataset.key] = e.target.value;
    clearTimeout(plannerSaveTimer);
    plannerSaveTimer = setTimeout(() => safeSave('ssh-planner', plannerData), 300);
  });

  // Assignment Tracker
  const assignmentForm = document.getElementById('assignment-form');
  const assignmentList = document.getElementById('assignment-list');
  const assignmentEmpty = document.getElementById('assignment-empty');
  let assignments = safeLoad('ssh-assignments', []);

  function daysUntil(dateStr) {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const due = new Date(dateStr + 'T00:00:00');
    return Math.round((due - today) / 86400000);
  }

  function renderAssignments() {
    const sorted = [...assignments].sort((a, b) => new Date(a.due) - new Date(b.due));
    assignmentEmpty.style.display = sorted.length ? 'none' : 'block';
    assignmentList.innerHTML = sorted.map(a => {
      const diff = daysUntil(a.due);
      const isDone = a.status === 'done';
      let stateClass = '';
      if (!isDone) {
        if (diff < 0) stateClass = 'overdue';
        else if (diff <= 2) stateClass = 'due-soon';
      }
      return `
        <li class="assignment-item ${stateClass} ${isDone ? 'is-done' : ''}" data-id="${a.id}">
          <div class="assignment-main">
            <h3>${a.title}</h3>
            <div class="assignment-meta">
              <span>${a.course || 'No course'}</span>
              <span>Due ${a.due}</span>
              <span class="priority-badge priority-${a.priority}">${a.priority}</span>
            </div>
          </div>
          <div class="assignment-actions">
            <select class="status-select" data-id="${a.id}">
              <option value="not-started" ${a.status === 'not-started' ? 'selected' : ''}>Not started</option>
              <option value="in-progress" ${a.status === 'in-progress' ? 'selected' : ''}>In progress</option>
              <option value="done" ${a.status === 'done' ? 'selected' : ''}>Done</option>
            </select>
            <button class="delete-btn" data-id="${a.id}">Delete</button>
          </div>
        </li>`;
    }).join('');
  }

  assignmentForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.getElementById('a-title').value.trim();
    const course = document.getElementById('a-course').value.trim();
    const due = document.getElementById('a-due').value;
    const priority = document.getElementById('a-priority').value;
    if (!title || !due) return;
    assignments.push({ id: uid(), title, course, due, priority, status: 'not-started' });
    safeSave('ssh-assignments', assignments);
    renderAssignments();
    assignmentForm.reset();
    document.getElementById('a-priority').value = 'medium';
  });

  assignmentList.addEventListener('change', (e) => {
    if (!e.target.classList.contains('status-select')) return;
    const item = assignments.find(a => a.id === e.target.dataset.id);
    if (item) {
      item.status = e.target.value;
      safeSave('ssh-assignments', assignments);
      renderAssignments();
    }
  });

  assignmentList.addEventListener('click', (e) => {
    if (!e.target.classList.contains('delete-btn')) return;
    assignments = assignments.filter(a => a.id !== e.target.dataset.id);
    safeSave('ssh-assignments', assignments);
    renderAssignments();
  });

  renderAssignments();

  // Pomodoro Timer
  const focusLenInput = document.getElementById('focus-len');
  const shortLenInput = document.getElementById('short-len');
  const longLenInput = document.getElementById('long-len');
  const pomodoroRing = document.getElementById('pomodoro-ring');
  const pomodoroTime = document.getElementById('pomodoro-time');
  const pomodoroSessionText = document.getElementById('pomodoro-session-text');
  const pomodoroStart = document.getElementById('pomodoro-start');
  const pomodoroReset = document.getElementById('pomodoro-reset');

  let pomodoroPhase = 'focus'; 
  let pomodoroRound = 1;
  let pomodoroTotalSeconds = (parseInt(focusLenInput.value, 10) || 25) * 60;
  let pomodoroRemaining = pomodoroTotalSeconds;
  let pomodoroInterval = null;
  let pomodoroRunning = false;

  function phaseLabel() {
    if (pomodoroPhase === 'focus') return `Round ${pomodoroRound} of 4 · Focus`;
    if (pomodoroPhase === 'short') return `Round ${pomodoroRound} of 4 · Short break`;
    return `Long break · Nice work`;
  }

  function phaseSeconds() {
    if (pomodoroPhase === 'focus') return (parseInt(focusLenInput.value, 10) || 25) * 60;
    if (pomodoroPhase === 'short') return (parseInt(shortLenInput.value, 10) || 5) * 60;
    return (parseInt(longLenInput.value, 10) || 15) * 60;
  }

  function formatTime(s) {
    const m = Math.floor(s / 60).toString().padStart(2, '0');
    const sec = Math.floor(s % 60).toString().padStart(2, '0');
    return `${m}:${sec}`;
  }

  function renderPomodoro() {
    pomodoroTime.textContent = formatTime(pomodoroRemaining);
    pomodoroSessionText.textContent = phaseLabel();
    const percent = ((pomodoroTotalSeconds - pomodoroRemaining) / pomodoroTotalSeconds) * 100;
    setRing(pomodoroRing, percent);
  }

  function advancePhase() {
    if (pomodoroPhase === 'focus') {
      if (pomodoroRound >= 4) {
        pomodoroPhase = 'long';
      } else {
        pomodoroPhase = 'short';
      }
    } else if (pomodoroPhase === 'short') {
      pomodoroRound += 1;
      pomodoroPhase = 'focus';
    } else {
      pomodoroRound = 1;
      pomodoroPhase = 'focus';
    }
    pomodoroTotalSeconds = phaseSeconds();
    pomodoroRemaining = pomodoroTotalSeconds;
  }

  function tickPomodoro() {
    pomodoroRemaining -= 1;
    if (pomodoroRemaining <= 0) {
      playChime();
      advancePhase();
      renderPomodoro();
      return;
    }
    renderPomodoro();
  }

  pomodoroStart.addEventListener('click', () => {
    if (pomodoroRunning) {
      clearInterval(pomodoroInterval);
      pomodoroRunning = false;
      pomodoroStart.textContent = 'Resume';
      return;
    }
    pomodoroRunning = true;
    pomodoroStart.textContent = 'Pause';
    pomodoroInterval = setInterval(tickPomodoro, 1000);
  });

  pomodoroReset.addEventListener('click', () => {
    clearInterval(pomodoroInterval);
    pomodoroRunning = false;
    pomodoroPhase = 'focus';
    pomodoroRound = 1;
    pomodoroTotalSeconds = phaseSeconds();
    pomodoroRemaining = pomodoroTotalSeconds;
    pomodoroStart.textContent = 'Start';
    renderPomodoro();
  });

  [focusLenInput, shortLenInput, longLenInput].forEach(input => {
    input.addEventListener('change', () => {
      if (!pomodoroRunning) {
        pomodoroTotalSeconds = phaseSeconds();
        pomodoroRemaining = pomodoroTotalSeconds;
        renderPomodoro();
      }
    });
  });

  renderPomodoro();

  // To-Do List
  const todoForm = document.getElementById('todo-form');
  const todoInput = document.getElementById('todo-input');
  const todoListEl = document.getElementById('todo-list');
  const todoCount = document.getElementById('todo-count');
  const filterBtns = document.querySelectorAll('.filter-btn');
  let todos = safeLoad('ssh-todos', []);
  let currentFilter = 'all';

  function renderTodos() {
    let visible = todos;
    if (currentFilter === 'active') visible = todos.filter(t => !t.completed);
    if (currentFilter === 'completed') visible = todos.filter(t => t.completed);

    todoListEl.innerHTML = visible.map(t => `
      <li class="todo-item ${t.completed ? 'is-complete' : ''}" data-id="${t.id}">
        <input type="checkbox" ${t.completed ? 'checked' : ''} aria-label="Mark complete">
        <span>${t.text}</span>
        <button class="delete-btn" aria-label="Delete task">Delete</button>
      </li>
    `).join('');

    const activeCount = todos.filter(t => !t.completed).length;
    todoCount.textContent = `${activeCount} task${activeCount === 1 ? '' : 's'} left`;
  }

  todoForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = todoInput.value.trim();
    if (!text) return;
    todos.push({ id: uid(), text, completed: false });
    safeSave('ssh-todos', todos);
    todoInput.value = '';
    renderTodos();
  });

  todoListEl.addEventListener('change', (e) => {
    if (e.target.type !== 'checkbox') return;
    const li = e.target.closest('.todo-item');
    const item = todos.find(t => t.id === li.dataset.id);
    if (item) {
      item.completed = e.target.checked;
      safeSave('ssh-todos', todos);
      renderTodos();
    }
  });

  todoListEl.addEventListener('click', (e) => {
    if (!e.target.classList.contains('delete-btn')) return;
    const li = e.target.closest('.todo-item');
    todos = todos.filter(t => t.id !== li.dataset.id);
    safeSave('ssh-todos', todos);
    renderTodos();
  });

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      currentFilter = btn.dataset.filter;
      renderTodos();
    });
  });

  renderTodos();

  // Exam Countdown
  const examForm = document.getElementById('exam-form');
  const examGrid = document.getElementById('exam-grid');
  const examEmpty = document.getElementById('exam-empty');
  let exams = safeLoad('ssh-exams', []);

  function renderExams() {
    const sorted = [...exams].sort((a, b) => new Date(a.datetime) - new Date(b.datetime));
    examEmpty.style.display = sorted.length ? 'none' : 'block';
    examGrid.innerHTML = sorted.map(ex => `
      <article class="exam-card" data-id="${ex.id}" data-datetime="${ex.datetime}">
        <button class="exam-delete" aria-label="Remove ${ex.name}" data-id="${ex.id}">✕</button>
        <h3>${ex.name}</h3>
        <p class="exam-date">${new Date(ex.datetime).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}</p>
        <div class="exam-countdown">
          <div><strong class="ec-days">0</strong><span>days</span></div>
          <div><strong class="ec-hours">0</strong><span>hrs</span></div>
          <div><strong class="ec-mins">0</strong><span>min</span></div>
        </div>
      </article>
    `).join('');
    updateExamCountdowns();
  }

  function updateExamCountdowns() {
    document.querySelectorAll('.exam-card').forEach(card => {
      const target = new Date(card.dataset.datetime).getTime();
      const diff = target - Date.now();
      const days = Math.floor(diff / 86400000);
      const hours = Math.floor((diff % 86400000) / 3600000);
      const mins = Math.floor((diff % 3600000) / 60000);

      card.classList.toggle('is-past', diff <= 0);
      card.classList.toggle('is-urgent', diff > 0 && diff <= 86400000);

      card.querySelector('.ec-days').textContent = diff > 0 ? Math.max(days, 0) : 0;
      card.querySelector('.ec-hours').textContent = diff > 0 ? Math.max(hours, 0) : 0;
      card.querySelector('.ec-mins').textContent = diff > 0 ? Math.max(mins, 0) : 0;
      if (diff <= 0) {
        card.querySelector('.exam-countdown').innerHTML = '<div><strong>Done</strong></div>';
      }
    });
  }

  setInterval(updateExamCountdowns, 60000);

  examForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('e-name').value.trim();
    const datetime = document.getElementById('e-datetime').value;
    if (!name || !datetime) return;
    exams.push({ id: uid(), name, datetime });
    safeSave('ssh-exams', exams);
    renderExams();
    examForm.reset();
  });

  examGrid.addEventListener('click', (e) => {
    if (!e.target.classList.contains('exam-delete')) return;
    exams = exams.filter(ex => ex.id !== e.target.dataset.id);
    safeSave('ssh-exams', exams);
    renderExams();
  });

  renderExams();

  // Notes Organizer
  const notesForm = document.getElementById('notes-form');
  const notesBoard = document.getElementById('notes-board');
  const notesEmpty = document.getElementById('notes-empty');
  const notesSearch = document.getElementById('notes-search');
  let notes = safeLoad('ssh-notes', []);

  function renderNotes() {
    const query = notesSearch.value.trim().toLowerCase();
    const filtered = notes.filter(n =>
      !query ||
      n.title.toLowerCase().includes(query) ||
      (n.tag || '').toLowerCase().includes(query) ||
      n.content.toLowerCase().includes(query)
    );
    notesEmpty.style.display = notes.length ? 'none' : 'block';
    notesBoard.innerHTML = filtered.map(n => `
      <div class="sticky-note" data-id="${n.id}">
        <button class="sticky-delete" aria-label="Remove note" data-id="${n.id}">✕</button>
        <h3>${n.title}</h3>
        ${n.tag ? `<span class="sticky-tag">#${n.tag}</span>` : ''}
        <p>${n.content}</p>
      </div>
    `).join('');
  }

  notesForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.getElementById('n-title').value.trim();
    const tag = document.getElementById('n-tag').value.trim();
    const content = document.getElementById('n-content').value.trim();
    if (!title || !content) return;
    notes.unshift({ id: uid(), title, tag, content });
    safeSave('ssh-notes', notes);
    renderNotes();
    notesForm.reset();
  });

  notesBoard.addEventListener('click', (e) => {
    if (!e.target.classList.contains('sticky-delete')) return;
    notes = notes.filter(n => n.id !== e.target.dataset.id);
    safeSave('ssh-notes', notes);
    renderNotes();
  });

  notesSearch.addEventListener('input', renderNotes);

  renderNotes();

  // Soothing Study Sounds (Web Audio API — generated, no files)
  const volumeSlider = document.getElementById('sound-volume');
  const activeSounds = {};

  function makeNoiseBuffer(ctx) {
    const bufferSize = ctx.sampleRate * 2;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    return buffer;
  }

  function startSound(type) {
    const ctx = ensureAudio();
    const gain = ctx.createGain();
    gain.gain.value = 0.9;
    gain.connect(masterGain);
    const cleanup = [];

    function noiseSource() {
      const src = ctx.createBufferSource();
      src.buffer = makeNoiseBuffer(ctx);
      src.loop = true;
      return src;
    }

    if (type === 'rain') {
      const src = noiseSource();
      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 1300;
      src.connect(filter); filter.connect(gain);
      src.start();
      cleanup.push(() => src.stop());
    } else if (type === 'whitenoise') {
      const src = noiseSource();
      src.connect(gain);
      gain.gain.value = 0.35;
      src.start();
      cleanup.push(() => src.stop());
    } else if (type === 'cafe') {
      const src = noiseSource();
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 650;
      filter.Q.value = 0.5;
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.12;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 150;
      lfo.connect(lfoGain); lfoGain.connect(filter.frequency);
      src.connect(filter); filter.connect(gain);
      src.start(); lfo.start();
      cleanup.push(() => { src.stop(); lfo.stop(); });
    } else if (type === 'lofi') {
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      osc1.type = 'sine'; osc1.frequency.value = 174;
      osc2.type = 'sine'; osc2.frequency.value = 174.7;
      gain.gain.value = 0.16;
      osc1.connect(gain); osc2.connect(gain);
      osc1.start(); osc2.start();
      cleanup.push(() => { osc1.stop(); osc2.stop(); });
    } else if (type === 'night') {
      const bed = noiseSource();
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 500;
      filter.Q.value = 0.7;
      const bedGain = ctx.createGain();
      bedGain.gain.value = 0.25;
      bed.connect(filter); filter.connect(bedGain); bedGain.connect(gain);
      bed.start();
      cleanup.push(() => bed.stop());

      const chirpInterval = setInterval(() => {
        const now = ctx.currentTime;
        for (let i = 0; i < 3; i++) {
          const t = now + i * 0.09;
          const osc = ctx.createOscillator();
          const og = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.value = 4200 + Math.random() * 300;
          og.gain.setValueAtTime(0, t);
          og.gain.linearRampToValueAtTime(0.05, t + 0.01);
          og.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
          osc.connect(og); og.connect(gain);
          osc.start(t); osc.stop(t + 0.08);
        }
      }, 1800 + Math.random() * 800);
      cleanup.push(() => clearInterval(chirpInterval));
    }

    return { stop: () => cleanup.forEach(fn => fn()) };
  }

  function stopSound(type) {
    if (activeSounds[type]) {
      activeSounds[type].stop();
      delete activeSounds[type];
    }
  }

  document.querySelectorAll('.sound-card').forEach(card => {
    const type = card.dataset.sound;
    const stateLabel = card.querySelector('.sound-state');
    card.addEventListener('click', () => {
      const playing = card.classList.toggle('is-playing');
      if (playing) {
        activeSounds[type] = startSound(type);
        stateLabel.textContent = 'Stop';
      } else {
        stopSound(type);
        stateLabel.textContent = 'Play';
      }
    });
  });

  volumeSlider.addEventListener('input', () => {
    if (masterGain) {
      masterGain.gain.value = (parseInt(volumeSlider.value, 10) / 100) * 0.5;
    }
  });

})();
